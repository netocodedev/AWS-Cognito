# TransformaTec-Aula145
Autenticação com AWS Cognito

Código para autenticar usuário cadastrado em uma User Pool no AWS Cognito.
